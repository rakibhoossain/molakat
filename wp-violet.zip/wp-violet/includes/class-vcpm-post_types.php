<?php
/**
 * Register custom post types
 *
 * @link       www.rakibhossain.cf
 * @since      1.0.0
 *
 * @package    Vcpm
 * @subpackage Vcpm/includes
 */
class Vcpm_Post_Types {

    /**
     * Create post types
     *
     * @link https://codex.wordpress.org/Function_Reference/register_post_type
     */
    public function vcpm_team() {
        $vcpm_team_params = array(
            'labels' => array(
                'name' => __( 'Members', 'vcpm' ),
                'singular_name' => __( 'Member' , 'vcpm'),
                'add_new' => __( 'Add New Member', 'vcpm' ),
                'add_new_item' => __( 'Add New Member', 'vcpm' ),
                'edit_item' => __( 'Edit Member', 'vcpm' ),
                'new_item' => __( 'Add New Member', 'vcpm' ),
                'view_item' => __( 'View Member', 'vcpm' ),
                'search_items' => __( 'Search Member', 'vcpm' ),
                'not_found' => __( 'No Member found', 'vcpm' ),
                'not_found_in_trash' => __( 'No Member found in trash', 'vcpm' )
            ),
            'menu_icon' => 'dashicons-groups',
            'supports' => array( 'title', 'thumbnail', 'editor'),
            'rewrite' => array(
                    "slug" => esc_attr__( 'teams', 'vcpm' ) // Permalinks format
                ),
            'public' => true,
            'has_archive' => true
        );
        register_post_type( 'team',
            apply_filters('vcpm_team_params', $vcpm_team_params)
        );
    }





}
